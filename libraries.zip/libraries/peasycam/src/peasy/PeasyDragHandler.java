package peasy;

public interface PeasyDragHandler {
	public void handleDrag(final double dx, final double dy);
}
